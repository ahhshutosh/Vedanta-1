## VEDANTA-1 Model Card

- Version: 7B Pre-alpha
- Intended Use: Research, Education, Government AI
...