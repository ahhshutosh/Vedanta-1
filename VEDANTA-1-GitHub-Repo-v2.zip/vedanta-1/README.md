# VEDANTA-1
India’s Open Frontier Foundation Model.

This repo contains model code, training scripts, inference, and evaluation tools for the VEDANTA-1 foundation model.
