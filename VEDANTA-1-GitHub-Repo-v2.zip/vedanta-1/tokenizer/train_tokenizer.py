
# tokenizer/train_tokenizer.py

from tokenizers import Tokenizer, models, pre_tokenizers, trainers, processors
from pathlib import Path

files = [str(p) for p in Path("data/raw/").glob("*.txt")]

tokenizer = Tokenizer(models.BPE())
tokenizer.pre_tokenizer = pre_tokenizers.Whitespace()

trainer = trainers.BpeTrainer(special_tokens=["<pad>", "<unk>", "<s>", "</s>"], vocab_size=32000)
tokenizer.train(files, trainer)

tokenizer.save("tokenizer/indic_sentencepiece.json")
