
# data/dataset_scripts/prepare_indic_corpus.py

import os
from datasets import Dataset, DatasetDict, load_dataset

# Load a raw corpus - example using OSCAR Hindi subset
dataset = load_dataset("oscar", "unshuffled_deduplicated_hi")

# Filter, clean, or merge other corpora here if needed
dataset["train"].train_test_split(test_size=0.1).save_to_disk("data/processed/")
