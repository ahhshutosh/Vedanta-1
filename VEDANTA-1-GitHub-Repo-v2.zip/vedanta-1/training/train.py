# Training script placeholder
print('Training VEDANTA-1')
