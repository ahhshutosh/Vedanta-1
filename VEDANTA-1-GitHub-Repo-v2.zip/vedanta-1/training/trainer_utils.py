# Utility functions for training
